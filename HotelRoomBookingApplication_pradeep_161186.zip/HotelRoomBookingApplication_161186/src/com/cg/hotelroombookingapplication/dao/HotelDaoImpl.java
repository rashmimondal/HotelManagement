package com.cg.hotelroombookingapplication.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.hotelroombookingapplication.model.HotelDetails;
@Repository
public class HotelDaoImpl  implements IHotelDao{
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public int addhotel(HotelDetails hotelDetails) {
		entityManager.persist(hotelDetails);

		int id = getMaxId();
		return id;
	}
	
	
	public int getMaxId() {

		String query = "select max(b.id) from HotelDetails b";
		Query result = entityManager.createQuery(query);
		int id = (Integer) result.getSingleResult();

		return id;
	}
	

}
