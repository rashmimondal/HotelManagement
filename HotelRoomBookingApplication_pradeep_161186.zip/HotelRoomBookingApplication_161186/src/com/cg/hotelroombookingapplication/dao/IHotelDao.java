package com.cg.hotelroombookingapplication.dao;

import com.cg.hotelroombookingapplication.model.HotelDetails;

public interface IHotelDao {

	int addhotel(HotelDetails hotelDetails);

}
