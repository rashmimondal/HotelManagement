package com.cg.hotelroombookingapplication.service;

import com.cg.hotelroombookingapplication.model.HotelDetails;

public interface IHotelService {

	int addHotelDetails(HotelDetails hotelDetails);

}
