package com.cg.hotelroombookingapplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hotelroombookingapplication.dao.IHotelDao;
import com.cg.hotelroombookingapplication.model.HotelDetails;

@Service
@Transactional
public class HotelServiceImpl  implements IHotelService{

	@Autowired
	IHotelDao hotelDao;
	@Override
	public int addHotelDetails(HotelDetails hotelDetails) {
		// TODO Auto-generated method stub
		return hotelDao.addhotel(hotelDetails);
	}

}
