package com.cg.hotelroombookingapplication.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.hotelroombookingapplication.model.HotelDetails;
import com.cg.hotelroombookingapplication.service.IHotelService;

@Controller
public class MyController {

	@Autowired
	IHotelService service;

	@RequestMapping("/home")
	public String showHotelDetailsPage() {
		String view = "home";
		return view;
	}

	@RequestMapping("/viewHotel")
	public String getHotelDetails(Model model) {

		String view = "HotelDetails";
		return view;
	}
     //BOOKING OF HILTON HOTEL
	@RequestMapping("/bookHiltonHotel")
	public String BookHiltonpage(Model model, HttpServletRequest request) {

		String view = "bookhilton";

		ServletContext context = request.getServletContext();
		model.addAttribute("book", new HotelDetails());

		return view;
	}

	@RequestMapping(value = "/bookhilton", method = RequestMethod.POST)
	public String registerHotelDetails(Model model, @Valid @ModelAttribute("book") HotelDetails hotelDetails,
			BindingResult result) {

		String view = "";

		if (result.hasErrors()) {
			view = "bookhilton";
		} else {

			int id = service.addHotelDetails(hotelDetails);

			if (id > 0) {
				view = "BookingConfirmation";
				model.addAttribute("id", id);
			} else {
				view = "error";
				model.addAttribute("error", "some problem occured");
			}
		}
		return view;
	}
////BOOKING OF VIVANTA HOTEL
	@RequestMapping("/bookVivantaByTajHotel")
	public String BookVivantapage(Model model, HttpServletRequest request) {

		String view = "bookvivanta";

		ServletContext context = request.getServletContext();
		model.addAttribute("book", new HotelDetails());

		return view;
	}

	@RequestMapping(value = "/bookvivanta", method = RequestMethod.POST)
	public String registerVivantaDetails(Model model, @Valid @ModelAttribute("book") HotelDetails hotelDetails,
			BindingResult result) {

		String view = "";

		if (result.hasErrors()) {
			view = "bookvivanta";
		} else {

			int id = service.addHotelDetails(hotelDetails);

			if (id > 0) {
				view = "BookingConfirmation";
				model.addAttribute("id", id);
			} else {
				view = "error";
				model.addAttribute("error", "some problem occured");
			}
		}
		return view;
	}
	//BOOKING OF GINGER HOTEL
	@RequestMapping("/bookNewGingerResort")
	public String BookGingerpage(Model model, HttpServletRequest request) {

		String view = "bookginger";

		ServletContext context = request.getServletContext();
		model.addAttribute("book", new HotelDetails());

		return view;
	}

	@RequestMapping(value = "/bookginger", method = RequestMethod.POST)
	public String registerGingerDetails(Model model, @Valid @ModelAttribute("book") HotelDetails hotelDetails,
			BindingResult result) {

		String view = "";

		if (result.hasErrors()) {
			view = "bookginger";
		} else {

			int id = service.addHotelDetails(hotelDetails);

			if (id > 0) {
				view = "BookingConfirmation";
				model.addAttribute("id", id);
			} else {
				view = "error";
				model.addAttribute("error", "some problem occured");
			}
		}
		return view;
	}
	//BOOKING OFWOODLANDS HOTEL
	@RequestMapping("/bookWoodlandsHotel")
	public String Bookwoodlandpage(Model model, HttpServletRequest request) {

		String view = "bookwoodland";

		ServletContext context = request.getServletContext();
		model.addAttribute("book", new HotelDetails());

		return view;
	}

	@RequestMapping(value = "/bookwoodland", method = RequestMethod.POST)
	public String registerwoodlandDetails(Model model, @Valid @ModelAttribute("book") HotelDetails hotelDetails,
			BindingResult result) {

		String view = "";

		if (result.hasErrors()) {
			view = "bookwoodland";
		} else {

			int id = service.addHotelDetails(hotelDetails);

			if (id > 0) {
				view = "BookingConfirmation";
				model.addAttribute("id", id);
			} else {
				view = "error";
				model.addAttribute("error", "some problem occured");
			}
		}
		return view;
	}

}
