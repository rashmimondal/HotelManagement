package com.cg.hotelroombookingapplication.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "hoteldetails")
public class HotelDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@NotEmpty(message = "should not empty")
	private String customerName;
	
	@NotEmpty(message = "should not empty")
	private String toDate;
	
	@NotEmpty(message = "should not empty")
	private String fromDate;
	
	@NotEmpty(message = "should not empty")
	private String numberOfRooms;
//DEFAULT CONSTRUCTOR
	public HotelDetails() {

	}
//ALL SETTERS AND GETTERS
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getNumberOfRooms() {
		return numberOfRooms;
	}

	public void setNumberOfRooms(String numberOfRooms) {
		this.numberOfRooms = numberOfRooms;
	}
//PARAMETERIZED CONSTRUCTOR
	public HotelDetails(Integer id, String customerName, String toDate, String fromDate, String numberOfRooms) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.toDate = toDate;
		this.fromDate = fromDate;
		this.numberOfRooms = numberOfRooms;
	}
//TOSTRING METHOD
	@Override
	public String toString() {
		return "HotelDetails [id=" + id + ", customerName=" + customerName + ", toDate=" + toDate + ", fromDate="
				+ fromDate + ", numberOfRooms=" + numberOfRooms + "]";
	}

}
